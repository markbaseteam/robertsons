# The Armorial Crest

In ancient times a chief wore in battle a distinguishing badge on his helmet, a device which his followers could recognize in the turmoil of action. This is known as the Crest of the Chief-which is surrounded by a Strap and Buckle Garter to denote his clan allegiance.

You will note the Robertson crest has a dexter arm holding up an Imperial
crown signifying that the Robertson Clan supported the king of Scotland, and it
bears the words ***Virtutis Gloria Merces*: Glory is the Reward of Virtue.**
The slogan or war cry of the Clan is ***Garg'n war dhursgeart:* Fierce when
roused.**

The Highland Clans never marched without a Piper — therefore the Pipes
must be considered as instruments of war.

![Fetching Title#e467](https://cdn-std.droplr.net/files/acc_10302/W9IuHr)