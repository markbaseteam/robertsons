# Robertson Clan Life
## 19th Century

The mountains are bleak. Bracken is the Robertson plant badge. It was only on the more sheltered ground above the swampy undrained river marshes that agriculture was possible. Here stood the townships or clachans of the Robertson clansfolk, together with the little towers and modest houses of their chiefs and lesser chieftains, whose rank was marked by eagle's feathers in their blue bonnets.

Attached to the Robertson tacks and crofts were usually a number of cottars, who helped to labor them in return for a couple of cows, and sufficient land to sow a planting of oats. Their thick walled rubble cottages often consisted of a single room with no window and one door where they huddled in winter around a fireplace in the riddle of the floor, while some of the peat smoke escaped upwards through a chimney hole. The roof was usually thatched with turf. Often a partition of clay and wattles divided the cottage, forming a second room to shelter the live stock in bitter weather.

The winter's evening ceilidh brought the clanfolks to-gether to hear or recite
poetry and tales of epic legend, to dance or listen to music. Harp and fiddle music was very popular and the bagpipes came into great favour.

Life was primitive in the old clan days. The shallow soil was broken with a crude
spade plough. The main crops were barley and oats, which provided bread and porridge, but potatoes became important by the nineteenth century. On the more level ground were "ploughs used with four small horses abreast, a man between the centre horse walking backwards to guide the plough from stones" In summer, the clansfolk's staple dish was a mixture of milk and whey, supplemented by fish caught locally. As winter came on, the beasts were slaughter to supply salt meat, nor was anything wasted in haggis. Even mutton was eaten from sheep found dead on the hillside. Those cattle that survived for breeding were bled for blood puddings, and in spring were often so weak that they had to be carried out to pasture in the "lifting time".

Summer shelters up on the moors afforded temporary protection for the women
and children who tended these beasts, but the forest was lonely and wild, and inhabited by wild cats, and red deer.

In the ancient Caledonian Forest patches of fir survive. Elsewhere in At foll some
oaks were planted, but birch woods predominate, with rowans and Alder by the burns.

The homeland of the historic Robertsons of Clan Donnachaidh is the picturesque
district of Altholl in the Perthshire highlands.

*The Robertsons*
Clan History
Iain Moncreiffe

**Next: [[The Armorial Crest]]**
