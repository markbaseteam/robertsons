# Introduction

For many years I have been collecting information about my father's family,
the ROBERTSONS. The final result of my research is this book, *THE
ROBERTSONS OF TARVIE: Descendants of WILLIAM ROBERTSON and CATHERINE SHINNERS.*

The Robertsons trace their ancestry back to the Parish of Contin, County Ross, Scotland. In 1840 William Robertson a soldier with the 93rd Regiment of Highlanders landed at Quebec to help defend Upper and Lower Canada against
the threatening onset of the U.S.A. After much diligent re-search we have never been able to ascertain when Catherine immigrated from County Clare, Ireland to the Ottawa Valley where it is thought that she met and married William.

To my cousin Karen Pendel great granddaughter of Alexander Robertson, I owe my gratitude and heart felt thanks for the many hours of re-search and on going interest. This book would not have been possible without the documentation and pictures she contributed so generously.

I am grateful to the many relatives both here in Ontario and scattered throughout the U.S.A. for the many family pictures. One example of such generosity are the copies of legal documentation pertaining to William Robertson provided by Keith Robertson.

I cherish the fond memories that I have of my father Russell Robertson who inspired in my a thirst for knowledge and a love of reading. His many stories of family lore have helped to enhance this book.

I also wish to acknowledge the assistance of staff at the Strathroy Public Library, Archives of Ontario, Toronto, and the National Archives of Canada, Ottawa, the Archives of Michigan and Wisconsin States, U.S.A.; Lambton County Library-Wyoming, Ontario; Military Records at Edinburgh and Sterling Castles; Scots Ancestry Research, Edinburgh, Scotland.

Finally, I must thank Wilma Reath for her support, and interest in editing and setting up this manuscript on her computer, and her suggestions regarding the placing of pictures and documents.

**Next: [[Robertson Clan Life]]**